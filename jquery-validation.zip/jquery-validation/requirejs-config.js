var config = {
	config: {
        mixins: {
            'mage/validation': {
                'js/mage/jquery-validate-mixin': true
            }
        }
    }
}